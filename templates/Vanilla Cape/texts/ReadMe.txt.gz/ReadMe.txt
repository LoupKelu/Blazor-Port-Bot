  _                  _  __    _      
 | |   ___ _  _ _ __| |/ /___| |_  _ 
 | |__/ _ \ || | '_ \ ' </ -_) | || |
 |____\___/\_,_| .__/_|\_\___|_|\_,_|
               |_|  Port Bot™        
                             
• iOS Cape Port by LoupKelu made in Port Bot™

                                           ↓↓ Port Bot™ ↓↓
• Please feel free to recommend people to discord.gg/fE3wRnjTeH


• Hello and Goodbye!